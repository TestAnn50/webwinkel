<?=template_header('Place Order')?>

<div class="placeorder content-wrapper">
    <h1>U bestelling is gereserveerd.</h1>
    <p>Bedankt voor jouw bestelling.</p>
</div>

<?=template_footer()?>